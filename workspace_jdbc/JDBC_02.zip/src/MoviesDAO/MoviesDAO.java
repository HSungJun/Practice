package MoviesDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DTO.MoviesDTO;

// manager > �����Ϳ� ���õ� ��� �۾��� �Ѱ��ϴ� Ŭ���� 
// DAO ��� ������ Data Access Object
// table���� DAO �� �ϳ��� ����
public class MoviesDAO {
	// ���� ���� - throws Exception > �����߻��� ����ó������ ����. ���� �߻��� ���� �������� ���ư�. main�� ��� �����߻�

	private Connection getConnection() throws Exception {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbID = "kh";
		String dbPW = "kh";
		Connection con = DriverManager.getConnection(url, dbID, dbPW);
		return con;
	}

	public int insert(String title, String genre) throws Exception {

		Connection con = this.getConnection();
		Statement stat = con.createStatement();

		String add_movie = "insert into movies values (movies_seq.nextval,'" + title + "','" + genre + "')";
		int result = stat.executeUpdate(add_movie);
		con.commit();
		con.close();
		return result;
	}

	public int update(String title, String genre, int id) throws Exception {

		Connection con = this.getConnection();
		Statement stat = con.createStatement();

		String update = "update movies set title = '" + title + "', genre = '" + genre + "' where id = " + id;
		int result = stat.executeUpdate(update);
		con.commit();
		con.close();
		return result;
	}

	public int delete(int id) throws Exception {
		Connection con = this.getConnection();
		Statement stat = con.createStatement();

		String del = "delete from movies where id = " + id;
		int result = stat.executeUpdate(del);
		con.commit();
		con.close();
		return result;
	}

	public List<MoviesDTO> selectAll() throws Exception {
		Connection con = this.getConnection();
		Statement stat = con.createStatement();

		String list = "select * from movies";
		ResultSet rs = stat.executeQuery(list);

		List<MoviesDTO> result = new ArrayList<>();

		while (rs.next()) {
			int id = rs.getInt("id");
			String title = rs.getString("title");
			String genre = rs.getString("genre");

			MoviesDTO dto = new MoviesDTO(id, title, genre);
			result.add(dto);

		}
		con.close();
		return result;
	}

	public List<MoviesDTO> search(String title) throws Exception {
		Connection con = this.getConnection();
		Statement stat = con.createStatement();

		String search = "select * from movies where title like '%" + title + "%'";
		ResultSet rs = stat.executeQuery(search);

		List<MoviesDTO> result = new ArrayList<>();

		while (rs.next()) {
			int searchId = rs.getInt("id");
			String searchTitle = rs.getString("title");
			String searchGenre = rs.getString("genre");

			MoviesDTO dto = new MoviesDTO(searchId, searchTitle, searchGenre);
			result.add(dto);

		}
		con.close();
		return result;
	}
	
	
	public boolean isIdExist (int id) throws Exception{
		
		
		
		return result;
		
	}
}










